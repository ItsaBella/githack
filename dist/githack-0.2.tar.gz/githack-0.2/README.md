# githack
This library was created as an example to test my understanding on how to publish a python package.
